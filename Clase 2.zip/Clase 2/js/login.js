var user=prompt('Ingrese su nombre de usuario: ')
var pass=prompt('Ingrese su clave: ')

// user: root   pass: 123

/*
if(user=='root'){
    if(pass=='123'){
        document.write('<h1>Bienvenidos al Sitio!</h1>')
    } else {
        document.write('<h3>Password Incorrecto!</h3>')
    }
} else {
    document.write('<h3>Usuario Incorrecto!</h3>')
}
*/

if(user=='root' && pass=='123') document.write('<h1>Bienvenidos al Sitio!</h1>')
if(user=='root' && pass!='123') document.write('<h3>Password Incorrecto!</h3>')
if(user!='root')                document.write('<h3>Usuario Incorrecto!</h3>')


