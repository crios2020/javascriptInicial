// Implementación Externa
console.log('Implementación Externa')