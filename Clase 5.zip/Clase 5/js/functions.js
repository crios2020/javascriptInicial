        // Eventos mouseOver mouseLeave

        var parrafo = document.getElementById('texto')

        //declaración de evento
        parrafo.onmouseover=mouseOver
        
        //declaración de función
        function mouseOver(){
            console.log('El mouse está por encima del parrafo!')
            parrafo.style.background='black'
            parrafo.style.color='white'
        }
        //mouseOver()

        parrafo.onmouseleave=mouseLeave
        function mouseLeave(){
            console.log('El mouse está fuera del parrafo!')
            parrafo.style.background=''
            parrafo.style.color=''
        }


        //Evento click
        var contador=0
        function representarContador(valor){
            var span=document.getElementById('contador')
            span.innerText=valor
        }
        representarContador(contador)

        function decrementar(){
            contador--
            if(contador<0) contador=0
            representarContador(contador)
        }

        function incrementar(){
            contador++
            representarContador(contador)
        }

        function reset(){
            contador=0
            representarContador(contador)
        }


        //Evento Input
        var input=document.getElementById('inputText')
        input.oninput=espejar

        function espejar(){
            var texto=input.value
            var span=document.getElementById('text')

            var array=texto.split('')
            array.reverse()
            var textoRevertido=array.join('')

            span.innerText=textoRevertido
        }

       

        function aparecer(){
            $('#caja').show()
        }

        function desaparecer(){
            $('#caja').hide()
        }

        function rojo(){
            $('#caja').css('background','red')
        }

        function amarillo(){
            $('#caja').css('background','yellow')
        }

        function verde(){
            $('#caja').css('background','green')
        }

        $('#aparecer').click(aparecer)
        $('#desaparecer').click(desaparecer)
        $('#rojo').click(rojo)
        $('#amarillo').click(amarillo)
        $('#verde').click(verde)

